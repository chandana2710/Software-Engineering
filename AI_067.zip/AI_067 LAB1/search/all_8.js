var searchData=
[
  ['se_20lab_3a_20assignment_20–_201_20doxygen_0',['SE Lab: Assignment – 1 (Doxygen)',['../index.html',1,'']]],
  ['subtract_1',['subtract',['../class_calculator.html#a3c8e20c48f94c55697f5d166f94d3442',1,'Calculator']]]
];
