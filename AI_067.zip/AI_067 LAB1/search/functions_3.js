var searchData=
[
  ['subtract_0',['subtract',['../class_calculator.html#a3c8e20c48f94c55697f5d166f94d3442',1,'Calculator']]]
];
