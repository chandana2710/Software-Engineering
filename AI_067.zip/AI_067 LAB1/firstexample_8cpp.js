var firstexample_8cpp =
[
    [ "Time", "class_time.html", "class_time" ]
];