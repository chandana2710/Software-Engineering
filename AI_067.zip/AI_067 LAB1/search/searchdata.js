var indexSectionsWithContent =
{
  0: "1acdeflnst–",
  1: "ct",
  2: "def",
  3: "adnst",
  4: "1adls–"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Pages"
};

