var files_dup =
[
    [ "doxygen_example.cpp", "doxygen__example_8cpp.html", "doxygen__example_8cpp" ],
    [ "example.h", "example_8h.html", "example_8h" ],
    [ "firstexample.cpp", "firstexample_8cpp.html", "firstexample_8cpp" ]
];