var annotated_dup =
[
    [ "Calculator", "class_calculator.html", "class_calculator" ],
    [ "Time", "class_time.html", "class_time" ]
];