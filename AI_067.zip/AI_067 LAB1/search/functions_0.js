var searchData=
[
  ['add_0',['add',['../class_calculator.html#a7d50f9c65e48c5c54e58a99bca4c0e43',1,'Calculator']]]
];
