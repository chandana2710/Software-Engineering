var class_calculator =
[
    [ "add", "class_calculator.html#a7d50f9c65e48c5c54e58a99bca4c0e43", null ],
    [ "subtract", "class_calculator.html#a3c8e20c48f94c55697f5d166f94d3442", null ]
];